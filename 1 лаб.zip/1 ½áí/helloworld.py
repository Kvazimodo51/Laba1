print("Hello world!")
